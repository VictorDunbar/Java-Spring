package ZooKeeper1;

public class DragonTest {
	public static void main(String[] args) {
		Dragon d = new Dragon();
		d.fly();
		d.eatHumans();
		d.eatHumans();
		d.fly();
		d.attackTown();
		d.attackTown();
		d.attackTown();
		d.eatHumans();
		d.eatHumans();
		d.displayEnergy();
		
	}

}
