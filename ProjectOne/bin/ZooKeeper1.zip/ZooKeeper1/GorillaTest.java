package ZooKeeper1;

public class GorillaTest {
	public static void main(String[] args) {
		Gorilla g = new Gorilla();
		g.throwSomething();
		g.throwSomething();
		//g.displayEnergy();
		g.eatBanana();
		g.climb();
		g.throwSomething();
		//g.displayEnergy();
		g.eatBanana();
		g.eatBanana();
		g.eatBanana();
		g.throwSomething();
		g.displayEnergy();
	}
}
